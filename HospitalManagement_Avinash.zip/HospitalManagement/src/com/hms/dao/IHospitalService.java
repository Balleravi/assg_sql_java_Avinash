
package com.hms.dao;

import java.util.List;

import com.hms.entity.Appointment;
import com.hms.entity.Patient;
import com.hms.exception.PatientNumberNotFoundException;

public interface IHospitalService {
	Appointment getAppointmentById(int appointmentId)throws PatientNumberNotFoundException;

	List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException;

	List<Appointment> getAppointmentsForDoctor(int doctorId)throws PatientNumberNotFoundException;

	boolean scheduleAppointment(Appointment appointment)throws PatientNumberNotFoundException;

	boolean updateAppointment(Appointment appointment)throws PatientNumberNotFoundException;

	boolean cancelAppointment(int appointmentId)throws PatientNumberNotFoundException;

	Patient findPatientById(int patientId) throws PatientNumberNotFoundException;

}