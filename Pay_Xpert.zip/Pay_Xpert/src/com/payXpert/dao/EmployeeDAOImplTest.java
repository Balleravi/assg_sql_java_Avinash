package com.payXpert.dao;



import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.payXpert.entity.Employee;
import com.payXpert.exception.EmployeeNotFoundException;

public class EmployeeDAOImplTest {
    private IEmployeeDAO employeeDAO;
   
	@Before
	public void setUp() throws Exception {
		employeeDAO = new EmployeeDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		employeeDAO = null;
	}

	@Test
	public final void testaddEmployee() {
		int result = 0;
		Employee employee = new Employee(15,"ashu", "km",LocalDate.of(1990, 5, 15),"Male" ,"kk@email.com", "9999999998","UTTAK","Mana",LocalDate.now(),LocalDate.of(2024, 5, 15));
		try {
			result = employeeDAO.addEmployee(employee);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		assertTrue(result == 1);
	} 

	@Test
	public final void testUpdateEmployee() {
		int result = 0;
		Employee employee = new Employee("ahu", "koisadm",LocalDate.of(1991, 9, 19),"Female" ,"kksasdd@email.com", "992329998","YaamK","WEESU",LocalDate.now(),LocalDate.of(2025, 8, 19));
		employee.setEmployeeID(15);
		try {
			result = employeeDAO.UpdateEmployee(employee);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (EmployeeNotFoundException cnfe) {
			System.out.println("No such Employee");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteCustomer() {
		int result = 0;
		int employeeId = 15;
		try {
			result = employeeDAO.deleteEmployee(employeeId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (EmployeeNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(result == 1);
	}

	@Test
	public final void testViewEmployeeById() {
		Employee employee = null;
		int employeeId = 1;
		try {
			employee = employeeDAO.viewEmployeeById(employeeId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (EmployeeNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(employee != null);
	}

	@Test
	public final void testViewEmployees() {
		List<Employee> employeeList = null;

		try {
			employeeList = employeeDAO.viewEmployees();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (EmployeeNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(employeeList != null);
	}

}