package com.payXpert.dao;


import java.sql.SQLException;
import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.payXpert.exception.FinancialRecordException;

public class FinancialRecordDAOImplTest {
	private IFinancialRecordDAO financialRecordDAO;
	
	@Before
	public void setUp() throws Exception {
		financialRecordDAO = new FinancialRecordDAOImpl();
	}


	@After
	public void tearDown() throws Exception {
		financialRecordDAO = null;
	}
	
	@Test
	public final void testaddFinancialRecord() {

		int employeeId=1; 
		LocalDate recordDate=LocalDate.of(2020, 10, 10);
		String description="tax_deduction";
		double amount=2000;
		String recordType="expense";
		try {
			financialRecordDAO.addFinancialRecord(employeeId, recordDate,description,amount,recordType);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (FinancialRecordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testgetFinancialRecordById() {
        // Test Generate Payroll method
		int recordId = 1;
        try {
        	financialRecordDAO.getFinancialRecordById(recordId);
        }	catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} 	catch (SQLException se) {
			System.out.println("Either employeeId ,startDate or endDate is wrong or duplicate record");
			se.printStackTrace();
		} catch (FinancialRecordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
        
        @Test
    	public void testgetFinancialRecordsForEmployee() {
            // Test Generate Payroll method
    		int employeeId = 1;
            try {
            	financialRecordDAO.getFinancialRecordsForEmployee(employeeId);
            }	catch (ClassNotFoundException cnfe) {
    			System.out.println("Looks like JDBC driver is NOT loaded.");
    		} 	catch (SQLException se) {
    			System.out.println("Either employeeId ,startDate or endDate is wrong or duplicate record");
    			se.printStackTrace();
    		} catch (FinancialRecordException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        }
            @Test
        	public void testgetFinancialRecordsForDate() {
                // Test Generate Payroll method
        		LocalDate recordDate = LocalDate.of(2023,12,01);
                try {
                	financialRecordDAO.getFinancialRecordsForDate(recordDate);
                }	catch (ClassNotFoundException cnfe) {
        			System.out.println("Looks like JDBC driver is NOT loaded.");
        		} 	catch (SQLException se) {
        			System.out.println("Either employeeId ,startDate or endDate is wrong or duplicate record");
        			se.printStackTrace();
        		} catch (FinancialRecordException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
	}

}
