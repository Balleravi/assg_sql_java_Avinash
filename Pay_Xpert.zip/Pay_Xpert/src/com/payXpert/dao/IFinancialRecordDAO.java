package com.payXpert.dao;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.payXpert.entity.FinancialRecord;
import com.payXpert.exception.FinancialRecordException;

	public interface IFinancialRecordDAO {
		
	    int addFinancialRecord(int employeeId,LocalDate recordDate, String description, double amount, String recordType)throws FinancialRecordException,ClassNotFoundException, SQLException;
	    
	    FinancialRecord getFinancialRecordById(int recordId)throws ClassNotFoundException, SQLException, FinancialRecordException;
	    
	    List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId)throws FinancialRecordException,ClassNotFoundException, SQLException;
	    
	    List<FinancialRecord> getFinancialRecordsForDate(LocalDate recordDate)throws FinancialRecordException,ClassNotFoundException, SQLException;
	}

