package com.payXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.payXpert.entity.FinancialRecord;
import com.payXpert.exception.FinancialRecordException;
import com.payXpert.util.DBUtil;

public class FinancialRecordDAOImpl implements IFinancialRecordDAO{
	private static Connection connection;

    static {
        try {
            connection = DBUtil.createConnection();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error establishing database connection.", e);
        }
    }


    @Override
    public int addFinancialRecord(int employeeId, LocalDate recordDate, String description, double amount, String recordType) throws ClassNotFoundException, SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int result = 0;

      
            connection = DBUtil.createConnection();
            String sql = "INSERT INTO financialrecord (employeeid, recordDate, Descript, Amount, recordType) VALUES (?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, employeeId);
            statement.setObject(2, recordDate);
            statement.setString(3, description);
            statement.setDouble(4, amount);
            statement.setString(5, recordType);

            result = statement.executeUpdate();
        
            DBUtil.closeConnection(connection);
        

        return result;
    }

	@Override
	public FinancialRecord getFinancialRecordById(int recordId) throws ClassNotFoundException, SQLException, FinancialRecordException {
		// TODO Auto-generated method stub
		FinancialRecord financialrecord = new FinancialRecord();
//		Integer StudentId=null;
		Integer employeeId=null;
	    String description = null;
	    double amount;
	    LocalDate recordDate = null;
	    String recordType = null;
	    
	    
		connection=DBUtil.createConnection();
		
		PreparedStatement statement = connection.prepareStatement("Select * from financialrecord where recordId=?");
    	statement.setInt(1, recordId);	
    	ResultSet rs  = statement.executeQuery();
   
    	if (!rs.next()) {
	        throw new FinancialRecordException("No Student Found.");
	    } else {
	    	do {
	    		employeeId=rs.getInt("employeeId");
	    		recordDate = rs.getDate("recordDate").toLocalDate();
	    		description=rs.getString("descript");
				amount=rs.getDouble("amount");
				recordType=rs.getString("recordType");
				
				financialrecord = new FinancialRecord(employeeId,recordDate,description,amount,recordType);
				financialrecord.setRecordId(recordId);
	    	} while (rs.next());
		}
    	DBUtil.closeConnection(connection);
    	return financialrecord;
    	}

	@Override
	public List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 List<FinancialRecord> financialRecordList = new ArrayList<>();

		    connection = DBUtil.createConnection();

		    PreparedStatement statement = connection.prepareStatement("SELECT * FROM financialrecord WHERE employeeId = ?");
		    statement.setInt(1, employeeId);

		    ResultSet rs = statement.executeQuery();

		    while (rs.next()) {
		        int recordId = rs.getInt("recordId"); 
		        LocalDate recordDate = rs.getDate("recordDate").toLocalDate();
		        String description = rs.getString("Descript");
		        double amount = rs.getDouble("Amount");
		        String recordType = rs.getString("recordType");

		        FinancialRecord financialRecord = new FinancialRecord(recordId, employeeId, recordDate, description, amount, recordType);
		        financialRecordList.add(financialRecord);
		    }

		    DBUtil.closeConnection(connection);
		    return financialRecordList;
		    }

	@Override
	public List<FinancialRecord> getFinancialRecordsForDate(LocalDate recordDate)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		List<FinancialRecord> financialRecordList = new ArrayList<>();

	    connection = DBUtil.createConnection();

	    PreparedStatement statement = connection.prepareStatement("SELECT * FROM financialrecord WHERE recordDate = ?");
	    statement.setObject(1, recordDate); // Convert LocalDate to java.sql.Date

	    ResultSet rs = statement.executeQuery();

	    while (rs.next()) {
	        int recordId = rs.getInt("recordId"); // Assuming "record_id" is the primary key of your financialrecord table
	        int employeeId = rs.getInt("employeeId"); // Assuming there's an "employeeId" column
	        LocalDate recordDateResult = rs.getDate("recordDate").toLocalDate();
	        String description = rs.getString("Descript");
	        double amount = rs.getDouble("Amount");
	        String recordType = rs.getString("recordType");

	        FinancialRecord financialRecord = new FinancialRecord(recordId, employeeId, recordDateResult, description, amount, recordType);
	        financialRecordList.add(financialRecord);
	    }

	    DBUtil.closeConnection(connection);
	    return financialRecordList;	
	    }

	

}
