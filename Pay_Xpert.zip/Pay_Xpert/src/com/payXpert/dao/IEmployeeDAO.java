package com.payXpert.dao;

import java.sql.SQLException;
import java.util.List;

import com.payXpert.entity.Employee;
import com.payXpert.exception.EmployeeNotFoundException;

public interface IEmployeeDAO {
	 public int addEmployee(Employee employee) throws ClassNotFoundException, SQLException;
	   public int UpdateEmployee(Employee employee )throws EmployeeNotFoundException, ClassNotFoundException, SQLException;
	   public int deleteEmployee(int EmployeeId)throws EmployeeNotFoundException, SQLException, ClassNotFoundException;
	   public List<Employee>viewEmployees()throws EmployeeNotFoundException, ClassNotFoundException, SQLException;
	public Employee viewEmployeeById(int employeeId) throws EmployeeNotFoundException, ClassNotFoundException, SQLException;

}
