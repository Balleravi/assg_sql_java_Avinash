package com.payXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.payXpert.entity.Payroll;
import com.payXpert.util.DBUtil;

public class PayrollDAOImpl implements IPayrollDAO {

	private static Connection connection;

    static {
        try {
            connection = DBUtil.createConnection();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error establishing database connection.", e);
        }
    }

    @Override
    public int generatePayroll(int employeeId, LocalDate startDate, LocalDate endDate) throws ClassNotFoundException, SQLException {
        connection=DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Payroll(Employee_ID, Pay_period_start, Pay_period_end) VALUES (?, ?, ?)");
            preparedStatement.setInt(1, employeeId);
            preparedStatement.setObject(2, startDate);
            preparedStatement.setObject(3, endDate);
            int res=preparedStatement.executeUpdate();
            DBUtil.closeConnection(connection);
            return res;

        } 
    

    @Override
    public Payroll getPayrollById(int payrollId) throws ClassNotFoundException, SQLException {
    	connection=DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM Payroll WHERE Payroll_ID = ?");
      
            preparedStatement.setInt(1, payrollId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                Payroll payroll = new Payroll();
                payroll.setPayrollID(resultSet.getInt("Payroll_ID"));
                payroll.setEmployeeID(resultSet.getInt("Employee_ID"));
   
                DBUtil.closeConnection(connection);
                return payroll;
            }
            DBUtil.closeConnection(connection);
			return null;
        }
    
    

    @Override
    public List<Payroll> getPayrollsForEmployee(int employeeId) throws ClassNotFoundException, SQLException {
        List<Payroll> payrolls = new ArrayList<>();
        connection=DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM Payroll WHERE Employee_ID = ?");
   
            preparedStatement.setInt(1, employeeId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                // Retrieve Payroll details from the result set and create Payroll objects
                Payroll payroll = new Payroll();
                payroll.setPayrollID(resultSet.getInt("Payroll_ID"));
                payroll.setEmployeeID(resultSet.getInt("Employee_ID"));
                // Set other payroll attributes accordingly
                payrolls.add(payroll);
            }
        
    DBUtil.closeConnection(connection);
        return payrolls;
    }

    @Override
    public List<Payroll> getPayrollsForPeriod(LocalDate startDate, LocalDate endDate) throws ClassNotFoundException, SQLException {
        List<Payroll> payrolls = new ArrayList<>();
        connection=DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM Payroll WHERE Pay_period_start >= ? AND Pay_period_end <= ?");
   
            preparedStatement.setObject(1, startDate);
            preparedStatement.setObject(2, endDate);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                // Retrieve Payroll details from the result set and create Payroll objects
                Payroll payroll = new Payroll();
                payroll.setPayrollID(resultSet.getInt("Payroll_ID"));
                payroll.setEmployeeID(resultSet.getInt("Employee_ID"));
                // Set other payroll attributes accordingly
                payrolls.add(payroll);
            }
            DBUtil.closeConnection(connection);
        return payrolls;
     
    }
}
