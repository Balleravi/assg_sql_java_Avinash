package com.payXpert.dao;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.payXpert.entity.Payroll;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;


public class IPayrollDAOImplTest {
	private IPayrollDAO PayrollDAO;
	
	@Before
	public void setUp() throws Exception {
		PayrollDAO = new PayrollDAOImpl();
	}
	
	@After
	public void tearDown() throws Exception {
		PayrollDAO = null;
	}

	@Test
	public void testGeneratePayroll() {
        // Test Generate Payroll method
        int employeeId = 1;
        LocalDate startDate = LocalDate.now().minusMonths(1);
        LocalDate endDate = LocalDate.now();
        
        try {
            PayrollDAO.generatePayroll(employeeId, startDate, endDate);
        }	catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} 	catch (SQLException se) {
			System.out.println("Either employeeId ,startDate or endDate is wrong or duplicate record");
			se.printStackTrace();
		}
    }

	@Test
	public void testGetPayrollById() throws ClassNotFoundException, SQLException {
        // Test Get Payroll by ID method
        int PayrollId = 1;
        Payroll Payroll = PayrollDAO.getPayrollById(PayrollId);
        assertNotNull(Payroll);
        
        try {
            PayrollDAO.getPayrollById(PayrollId);
        } catch (SQLException se) {
        	System.out.println("PayrollId  is wrong or duplicate record");
        	se.printStackTrace();
        } catch (ClassNotFoundException cnfe) {
        	System.out.println("Looks like JDBC driver is NOT loaded.");
        }
    }
	
	@Test
	public void testGetPayrollsForEmployee() throws ClassNotFoundException, SQLException {
        // Test Get Payrolls for Employee method
        int employeeId = 1;
        List<Payroll> Payroll = PayrollDAO.getPayrollsForEmployee(employeeId);
        
        assertNotNull(Payroll);
        
        try {
            PayrollDAO.getPayrollsForEmployee(employeeId);
        } catch (SQLException se) {
        	System.out.println("employeeId is wrong or duplicate record");
        	se.printStackTrace();
        } catch (ClassNotFoundException cnfe) {
        	System.out.println("Looks like JDBC driver is NOT loaded.");
        }
    }
	
	@Test
	public void testGetPayrollsForPeriod() throws ClassNotFoundException, SQLException {
        // Test Get Payrolls for Period method
        LocalDate startDate = LocalDate.now().minusMonths(1);
        LocalDate endDate = LocalDate.now();
        
        List<Payroll> payrolls = PayrollDAO.getPayrollsForPeriod(startDate, endDate);
        
        assertNotNull(payrolls);
        
        try {
            PayrollDAO.getPayrollsForPeriod(startDate, endDate);
        } catch (SQLException se) {
        	System.out.println("Either startDate or endDate is wrong or duplicate record");
        	se.printStackTrace();
        } catch (ClassNotFoundException cnfe) {
        	System.out.println("Looks like JDBC driver is NOT loaded.");
        }
    }
}