package com.payXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.payXpert.entity.Employee;
import com.payXpert.exception.EmployeeNotFoundException;
import com.payXpert.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO {


  private static Connection connEmployee;



	@Override
	public int addEmployee(Employee employee) throws ClassNotFoundException, SQLException  {
		// TODO Auto-generated method stub
		PreparedStatement statement = null;
		int result = 0;
		try {
		     connEmployee=DBUtil.createConnection();
		
			statement = connEmployee.prepareStatement("INSERT INTO employee (employee_id,first_Name,last_Name,DOB ,Gender,email,Phone_Number,Address,Position,Joining_Date,Termination_Date) VALUES ( ?, ? ,?,  ?, ?,?,?,?,?,?,?)");
			statement.setInt(1, employee.getEmployeeID());
    		statement.setString(2, employee.getFirstName());
    		statement.setString(3, employee.getLastName());
    		statement.setObject(4, employee.getDateOfBirth() );
    		statement.setString(5, employee.getGender());
    		statement.setString(6, employee.getEmail());
    		statement.setString(7, employee.getPhoneNumber());
    		statement.setObject(8, employee.getAddress() );
    		statement.setString(9, employee.getPosition());
    		statement.setObject(10, employee.getJoiningDate());
    		statement.setObject(11, employee.getTerminationDate());
    	
		 result = statement.executeUpdate();
		System.out.println(employee);
		}finally
		{
			DBUtil.closeConnection(connEmployee);
	        if (statement != null) {
	        	statement.close();
	        }
	        if (connEmployee != null) {
	        	connEmployee.close();
            }
		}
		return result;
		
	}
	
	@Override
	public int UpdateEmployee(Employee employee) throws ClassNotFoundException,SQLException, EmployeeNotFoundException {
		 Connection connection = null;
		    PreparedStatement statement = null;
		    int rowsAffected = 0;
		    connEmployee=DBUtil.createConnection();
		    try {
		       
		        String query = "UPDATE employee SET first_Name=?, last_Name=?, DOB=?, Gender=?, email=?, Phone_Number=?, Address=?, Position=?, Joining_Date=?, Termination_Date=? WHERE employee_id=?";
		        statement = connEmployee.prepareStatement(query);

		        statement.setString(1, employee.getFirstName());
		        statement.setString(2, employee.getLastName());
		        statement.setObject(3, employee.getDateOfBirth());
		        statement.setString(4, employee.getGender());
		        statement.setString(5, employee.getEmail());
		        statement.setString(6, employee.getPhoneNumber());
		        statement.setObject(7, employee.getAddress());
		        statement.setString(8, employee.getPosition());
		        statement.setObject(9, employee.getJoiningDate());
		        statement.setObject(10, employee.getTerminationDate());
		        statement.setInt(11, employee.getEmployeeID());

		        rowsAffected = statement.executeUpdate();
		    } finally {
		        // Close resources in a finally block
		        if (statement != null) {
		            statement.close();
		        }
		        if (connection != null) {
		            connection.close();
		        }
		    }

		    return rowsAffected;
	}

	@Override
	public int deleteEmployee(int employeeId) throws EmployeeNotFoundException ,SQLException,ClassNotFoundException {
		// TODO Auto-generated method stub
		

		 String firstName = null;
		 String lastName = null;
		 LocalDate dateOfBirth = null;
		 String gender = null;
		 String email = null;
		 String address = null;
		 String phoneNumber = null;
		 String position = null ;
		 LocalDate joiningDate = null;
		 LocalDate terminationDate = null;
		 Employee employee = null;
		    int result = 0;

		    Connection connEmployee = null;
		    PreparedStatement prepareStEmployee = null;
		    PreparedStatement prepareEmployeeDelete = null;

		    try {
		        connEmployee = DBUtil.createConnection();

		        String queryCheck = "SELECT * FROM employee WHERE employee_ID = ?";
		        String queryDelete = "DELETE FROM employee WHERE employee_ID = ?";

		        prepareStEmployee = connEmployee.prepareStatement(queryCheck);
		        prepareEmployeeDelete = connEmployee.prepareStatement(queryDelete);

		        prepareStEmployee.setInt(1, employeeId);
		        prepareEmployeeDelete.setInt(1, employeeId);

		        ResultSet rsEmployee = prepareStEmployee.executeQuery();

		        while (rsEmployee.next()) {
		            // Retrieve employee details if found
		            employeeId = rsEmployee.getInt("Employee_Id");
		             firstName = rsEmployee.getString("First_Name");
		             lastName = rsEmployee.getString("Last_Name");
		             dateOfBirth = rsEmployee.getObject("DOB", LocalDate.class);
		             gender = rsEmployee.getString("Gender");
		             email = rsEmployee.getString("Email");
		             address = rsEmployee.getString("Address");
		             phoneNumber = rsEmployee.getString("Phone_Number");
		             position = rsEmployee.getString("Position");
		             joiningDate = rsEmployee.getObject("Joining_Date", LocalDate.class);
		             terminationDate = rsEmployee.getObject("Termination_Date", LocalDate.class);

		            employee = new Employee(firstName, lastName, dateOfBirth, gender, email, address, phoneNumber, position, joiningDate, terminationDate);
		            employee.setEmployeeID(employeeId);
		        }

		        if (employee == null) {
		            throw new EmployeeNotFoundException("No Employee Found");
		        } else {
		            result = prepareEmployeeDelete.executeUpdate();
		        }
		    } finally {
		        // Close resources in a finally block
		        if (prepareEmployeeDelete != null) {
		            prepareEmployeeDelete.close();
		        }
		        if (prepareStEmployee != null) {
		            prepareStEmployee.close();
		        }
		        if (connEmployee != null) {
		            connEmployee.close();
		        }
		    }

		    return result;
		
	}

	@Override
	public Employee viewEmployeeById(int employeeId) throws ClassNotFoundException,SQLException,EmployeeNotFoundException {
		   Employee employee = null;

		    Connection connEmployee = null;
		    PreparedStatement pstn = null;
		    ResultSet rsEmployee = null;

		    try {
		        connEmployee = DBUtil.createConnection();
		        String Query1 = "SELECT * FROM employee WHERE employee_ID=?";
		        pstn = connEmployee.prepareStatement(Query1);
		        pstn.setInt(1, employeeId);
		        rsEmployee = pstn.executeQuery();

		        while (rsEmployee.next()) {
		            // Retrieve employee details if found
		            employeeId = rsEmployee.getInt("Employee_Id");
		            String firstName = rsEmployee.getString("First_Name");
		            String lastName = rsEmployee.getString("Last_Name");
		            LocalDate dateOfBirth = rsEmployee.getObject("DOB", LocalDate.class);
		            String gender = rsEmployee.getString("Gender");
		            String email = rsEmployee.getString("Email");
		            String address = rsEmployee.getString("Address");
		            String phoneNumber = rsEmployee.getString("Phone_Number");
		            String position = rsEmployee.getString("Position");
		            LocalDate joiningDate = rsEmployee.getObject("Joining_Date", LocalDate.class);
		            LocalDate terminationDate = rsEmployee.getObject("Termination_Date", LocalDate.class);

		            employee = new Employee(firstName, lastName, dateOfBirth, gender, email, address, phoneNumber, position, joiningDate, terminationDate);
		            employee.setEmployeeID(employeeId);
		        }

		        if (employee == null) {
		            throw new EmployeeNotFoundException("No Employee Found");
		        }
		    } finally {
		        // Close resources in a finally block
		        if (rsEmployee != null) {
		            rsEmployee.close();
		        }
		        if (pstn != null) {
		            pstn.close();
		        }
		        if (connEmployee != null) {
		            connEmployee.close();
		        }
		    }

		    return employee;
		
	}

	@Override
	public List<Employee> viewEmployees() throws EmployeeNotFoundException,ClassNotFoundException,SQLException {
		 List<Employee> employees = new ArrayList<>();

		    Connection connEmployee = null;
		    PreparedStatement pstn = null;
		    ResultSet rsEmployee = null;

		    try {
		        connEmployee = DBUtil.createConnection();
		        String Query1 = "SELECT * FROM employee";
		        pstn = connEmployee.prepareStatement(Query1);
		        rsEmployee = pstn.executeQuery();

		        while (rsEmployee.next()) {
		            int employeeId = rsEmployee.getInt("Employee_Id");
		            String firstName = rsEmployee.getString("First_Name");
		            String lastName = rsEmployee.getString("Last_Name");
		            LocalDate dateOfBirth = rsEmployee.getObject("DOB", LocalDate.class);
		            String gender = rsEmployee.getString("Gender");
		            String email = rsEmployee.getString("Email");
		            String address = rsEmployee.getString("Address");
		            String phoneNumber = rsEmployee.getString("Phone_Number");
		            String position = rsEmployee.getString("Position");
		            LocalDate joiningDate = rsEmployee.getObject("Joining_Date", LocalDate.class);
		            LocalDate terminationDate = rsEmployee.getObject("Termination_Date", LocalDate.class);

		            Employee employee = new Employee(firstName, lastName, dateOfBirth, gender, email, address, phoneNumber, position, joiningDate, terminationDate);
		            employee.setEmployeeID(employeeId);

		            employees.add(employee);
		        }

		        if (employees.isEmpty()) {
		            throw new EmployeeNotFoundException("No Employees Found");
		        }
		    } finally {
		        // Close resources in a finally block
		        if (rsEmployee != null) {
		            rsEmployee.close();
		        }
		        if (pstn != null) {
		            pstn.close();
		        }
		        if (connEmployee != null) {
		            connEmployee.close();
		        }
		    }

		    return employees;
		
	}

	

}
