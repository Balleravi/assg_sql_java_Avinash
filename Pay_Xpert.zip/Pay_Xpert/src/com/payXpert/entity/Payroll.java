package com.payXpert.entity;

import java.time.LocalDate;

public class Payroll {
	private int payrollID;
	private int employeeID;
	private LocalDate startDate;
	private LocalDate endDate;
	private double basicSalary;
	private double overtimePay;
	private double deductions;
	private double netSalary;
	
	public Payroll() {
        
    }

	public Payroll(int payrollID, int employeeID, LocalDate startDate, LocalDate endDate,
			double basicSalary, double overtimePay, double deductions, double netSalary) {
		super();
		this.payrollID = payrollID;
		this.employeeID = employeeID;
		this.startDate = startDate;
		this.endDate = endDate;
		this.basicSalary = basicSalary;
		this.overtimePay = overtimePay;
		this.deductions = deductions;
		this.netSalary = netSalary;
	}

	public int getPayrollID() {
		return payrollID;
	}

	public void setPayrollID(int payrollID) {
		this.payrollID = payrollID;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public LocalDate startDate() {
		return startDate;
	}

	public void startDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate endDate() {
		return endDate;
	}

	public void endDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "Payroll [payrollID=" + payrollID + ", employeeID=" + employeeID + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", basicSalary=" + basicSalary + ", overtimePay=" + overtimePay
				+ ", deductions=" + deductions + ", netSalary=" + netSalary + "]";
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public double getOvertimePay() {
		return overtimePay;
	}

	public void setOvertimePay(double overtimePay) {
		this.overtimePay = overtimePay;
	}

	public double getDeductions() {
		return deductions;
	}

	public void setDeductions(double deductions) {
		this.deductions = deductions;
	}

	public double getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}

}
