package com.payXpert.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.payXpert.dao.FinancialRecordDAOImpl;
import com.payXpert.dao.IFinancialRecordDAO;
import com.payXpert.entity.FinancialRecord;
import com.payXpert.exception.FinancialRecordException;

public class FinancialRecordServiceImpl implements IFinancialRecordService {
	private IFinancialRecordDAO financialrecordDAO;

	public FinancialRecordServiceImpl() {
		// TODO Auto-generated constructor stub
		this.financialrecordDAO = new FinancialRecordDAOImpl();
	}

	@Override
	public int addFinancialRecord(int employeeId, LocalDate recordDate, String description, double amount,String recordType) {
		// TODO Auto-generated method stub
		int result = 0;
		try {
			result = financialrecordDAO.addFinancialRecord(employeeId, recordDate, description,amount, recordType);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		
		  catch (FinancialRecordException e) { // TODO Auto-generated catch block
		  e.printStackTrace(); }
		 
		System.out.println(result);
		return result;
	}

		
	

	@Override
	public FinancialRecord getFinancialRecordById(int recordId) {
		// TODO Auto-generated method stub
		FinancialRecord financialrecord = new FinancialRecord(); 
		try {
			IFinancialRecordDAO ifinancialrecorddao= new FinancialRecordDAOImpl();
			financialrecord = ifinancialrecorddao.getFinancialRecordById(recordId);
		} 
			  catch(FinancialRecordException e) { 
				  e.printStackTrace(); 
				  } catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return financialrecord;
	}	

	@Override
	public List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId) {
		// TODO Auto-generated method stub
		List<FinancialRecord> financialrecordList = new ArrayList<>();
		try {
			IFinancialRecordDAO ifinancialrecorddao= new FinancialRecordDAOImpl();
			financialrecordList = ifinancialrecorddao.getFinancialRecordsForEmployee(employeeId);
		} 
			  catch(FinancialRecordException e) {
				  e.printStackTrace(); 
				  } catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return financialrecordList;
		}

	@Override
	public List<FinancialRecord> getFinancialRecordsForDate(LocalDate recordDate) {
		// TODO Auto-generated method stub
		List<FinancialRecord> financialrecordList = new ArrayList<>();
		try {
			IFinancialRecordDAO ifinancialrecorddao= new FinancialRecordDAOImpl();
			financialrecordList = ifinancialrecorddao.getFinancialRecordsForDate(recordDate);
		} 
			  catch(FinancialRecordException e) { 
				  e.printStackTrace(); 
				  }catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return financialrecordList;
		}

}
