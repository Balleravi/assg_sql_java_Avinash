package com.payXpert.service;

import com.payXpert.dao.ITaxDAO;

import com.payXpert.entity.Tax;
import com.payXpert.exception.TaxCalculationException;

import java.sql.SQLException;
import java.util.List;

public class TaxServiceImpl implements ITaxService {
    private final ITaxDAO taxDAO;

    public TaxServiceImpl(ITaxDAO taxDAO) {
        this.taxDAO = taxDAO;
    }

    @Override
    public double calculateTax(int employeeId, String taxYear) throws TaxCalculationException {
        try {
            return taxDAO.calculateTax(employeeId, taxYear);
        } catch (SQLException e) {
            handleSQLException(e);
            return 0.0;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return 0.0;
        }
    }


    @Override
    public Tax getTaxById(int taxId) {
        try {
            return taxDAO.getTaxById(taxId);
        } catch (SQLException e) {
            handleSQLException(e);
            return null;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return null;
        }
    }

    @Override
    public List<Tax> getTaxesForEmployee(int employeeId) {
        try {
            return taxDAO.getTaxesForEmployee(employeeId);
        } catch (SQLException e) {
            handleSQLException(e);
            return null;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return null;
        }
    }

    @Override
    public List<Tax> getTaxesForYear(String taxYear) {
        try {
            return taxDAO.getTaxesForYear(taxYear);
        } catch (SQLException e) {
            handleSQLException(e);
            return null;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return null;
        }
    }

    private void handleSQLException(SQLException e) {
        System.err.println("SQL Exception: " + e.getMessage());
        e.printStackTrace();  // log or handle the exception as needed
    }

    private void handleClassNotFoundException(ClassNotFoundException cnfe) {
        System.err.println("JDBC Driver not found: " + cnfe.getMessage());
        cnfe.printStackTrace();  // log or handle the exception as needed
    }
}
