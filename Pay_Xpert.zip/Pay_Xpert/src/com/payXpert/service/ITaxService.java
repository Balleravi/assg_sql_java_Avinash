package com.payXpert.service;

import com.payXpert.entity.Tax;

import com.payXpert.exception.TaxCalculationException;

import java.util.List;

public interface ITaxService {

    double calculateTax(int employeeId, String taxYear) throws TaxCalculationException;
    Tax getTaxById(int taxId);
    List<Tax> getTaxesForEmployee(int employeeId);
    List<Tax> getTaxesForYear(String taxYear);
}
