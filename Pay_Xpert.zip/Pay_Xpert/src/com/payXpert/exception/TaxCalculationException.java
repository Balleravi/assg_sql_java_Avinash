package com.payXpert.exception;

public class TaxCalculationException extends Exception {

	private static final long serialVersionUID = 1L;

	public TaxCalculationException() {
		// TODO Auto-generated constructor stub
	}

	public TaxCalculationException(String message) {
		super(message);
		
	}


}
