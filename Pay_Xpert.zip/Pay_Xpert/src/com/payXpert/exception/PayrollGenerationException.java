package com.payXpert.exception;

public class PayrollGenerationException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public PayrollGenerationException() {
		
	}

	public PayrollGenerationException(String message) {
		super(message);
		
	}
}
