package com.payXpert.exception;

public class FinancialRecordException extends Exception {
	private static final long serialVersionUID = 1L;

	public FinancialRecordException() {
		
	}

	public FinancialRecordException(String message) {
		super(message);
		
	}
}
